# Project status — 0.1.0

Implemented in this starter:
- Native Compose dashboard
- Android Keystore-backed PIN verifier
- SAF folder-based APK discovery
- Bulk deletion with per-item success/failure accounting
- Device Owner detection and one supported user restriction helper

Not yet implemented:
- Production DNS/VPN website filter
- Enterprise app allowlist backed by Managed Google Play / EMM
- Persistent Room audit database
- Full automated test suite and signed release pipeline

Do not advertise unimplemented modules as active protection.
