package com.lockguard.app.storage

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ApkDocument(
    val uri: Uri,
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val lastModified: Long
)

data class CleanupResult(
    val deleted: Int,
    val failed: Int,
    val bytesRecovered: Long,
    val deletedUris: Set<String>
)

class ApkScanner(private val context: Context) {

    suspend fun scanTree(treeUri: Uri): List<ApkDocument> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val results = mutableListOf<ApkDocument>()

        fun walk(directory: DocumentFile, prefix: String) {
            directory.listFiles().forEach { child ->
                val name = child.name ?: "unnamed"
                val relative = if (prefix.isBlank()) name else "$prefix/$name"
                if (child.isDirectory) {
                    walk(child, relative)
                } else if (name.endsWith(".apk", ignoreCase = true) && child.canRead()) {
                    results += ApkDocument(
                        uri = child.uri,
                        name = name,
                        path = relative,
                        sizeBytes = child.length().coerceAtLeast(0L),
                        lastModified = child.lastModified()
                    )
                }
            }
        }

        walk(root, "")
        results.sortedBy { it.name.lowercase() }
    }

    suspend fun deleteSelected(items: List<ApkDocument>): CleanupResult =
        withContext(Dispatchers.IO) {
            var deleted = 0
            var failed = 0
            var bytes = 0L
            val deletedUris = mutableSetOf<String>()

            items.forEach { item ->
                val document = DocumentFile.fromSingleUri(context, item.uri)
                if (document != null && document.delete()) {
                    deleted++
                    bytes += item.sizeBytes
                    deletedUris += item.uri.toString()
                } else {
                    failed++
                }
            }
            CleanupResult(deleted, failed, bytes, deletedUris)
        }
}
