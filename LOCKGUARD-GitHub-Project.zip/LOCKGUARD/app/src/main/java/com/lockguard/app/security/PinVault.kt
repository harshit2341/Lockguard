package com.lockguard.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.security.SecureRandom

/**
 * Stores only an encrypted PBKDF2 verifier. The encryption key is kept in Android Keystore.
 * This protects local-at-rest data; it is not a remote identity or enterprise recovery system.
 */
class PinVault(context: Context) {
    private val prefs = context.getSharedPreferences("lockguard_pin", Context.MODE_PRIVATE)
    private val alias = "lockguard_pin_aes_key"

    fun hasPin(): Boolean = prefs.contains("verifier")

    fun setPin(pin: CharArray) {
        require(pin.size in 6..12) { "PIN must contain 6 to 12 digits." }
        require(pin.all { it.isDigit() }) { "PIN must contain digits only." }

        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val verifier = derive(pin, salt)
        val encrypted = encrypt(verifier)
        prefs.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("verifier", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
        pin.fill('\u0000')
    }

    fun verify(pin: CharArray): Boolean {
        val saltText = prefs.getString("salt", null) ?: return false
        val verifierText = prefs.getString("verifier", null) ?: return false
        return try {
            val salt = Base64.decode(saltText, Base64.NO_WRAP)
            val storedEncrypted = Base64.decode(verifierText, Base64.NO_WRAP)
            val stored = decrypt(storedEncrypted)
            val candidate = derive(pin, salt)
            pin.fill('\u0000')
            java.security.MessageDigest.isEqual(stored, candidate)
        } catch (_: Exception) {
            pin.fill('\u0000')
            false
        }
    }

    private fun derive(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, 180_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        return iv + cipher.doFinal(data)
    }

    private fun decrypt(payload: ByteArray): ByteArray {
        require(payload.size > 12)
        val iv = payload.copyOfRange(0, 12)
        val ciphertext = payload.copyOfRange(12, payload.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }
}
