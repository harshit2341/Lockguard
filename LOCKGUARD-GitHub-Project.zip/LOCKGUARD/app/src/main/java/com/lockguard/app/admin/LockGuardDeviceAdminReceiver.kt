package com.lockguard.app.admin

import android.app.admin.DeviceAdminReceiver

class LockGuardDeviceAdminReceiver : DeviceAdminReceiver()
