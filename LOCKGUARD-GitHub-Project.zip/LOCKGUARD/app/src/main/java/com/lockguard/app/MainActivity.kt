package com.lockguard.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.lockguard.app.admin.LockGuardDeviceAdminReceiver
import com.lockguard.app.security.PinVault
import com.lockguard.app.storage.ApkDocument
import com.lockguard.app.storage.ApkScanner
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private val Bg = Color(0xFF0B0D10)
private val SurfaceDark = Color(0xFF15191F)
private val SurfaceLight = Color(0xFF20262E)
private val Accent = Color(0xFFE34B55)
private val TextMain = Color(0xFFF4F5F7)
private val TextMuted = Color(0xFF9AA4B2)
private val Green = Color(0xFF55C98A)
private val Amber = Color(0xFFFFC15A)

class MainActivity : ComponentActivity() {
    private lateinit var vault: PinVault
    private lateinit var scanner: ApkScanner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vault = PinVault(this)
        scanner = ApkScanner(this)

        setContent {
            LockGuardTheme {
                LockGuardApp(
                    context = this,
                    vault = vault,
                    scanner = scanner
                )
            }
        }
    }
}

@Composable
private fun LockGuardTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = SurfaceDark,
            onBackground = TextMain,
            onSurface = TextMain
        ),
        content = content
    )
}

@Composable
private fun LockGuardApp(
    context: Context,
    vault: PinVault,
    scanner: ApkScanner
) {
    var screen by remember { mutableStateOf("home") }
    var protectionOn by remember { mutableStateOf(false) }
    var pinConfigured by remember { mutableStateOf(vault.hasPin()) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun requireAdmin(action: () -> Unit) {
        if (!pinConfigured) {
            pendingAction = action
            screen = "pin_setup"
        } else {
            pendingAction = action
            showPinDialog = true
        }
    }

    if (showPinDialog) {
        PinDialog(
            title = "Administrator authentication",
            confirmLabel = "Verify",
            onDismiss = { showPinDialog = false },
            onConfirm = { pin ->
                val ok = vault.verify(pin.toCharArray())
                showPinDialog = false
                if (ok) pendingAction?.invoke()
            }
        )
    }

    when (screen) {
        "pin_setup" -> PinSetupScreen(
            onBack = { screen = "home" },
            onSave = { pin ->
                vault.setPin(pin.toCharArray())
                pinConfigured = true
                val action = pendingAction
                pendingAction = null
                screen = "home"
                action?.invoke()
            }
        )
        "cleanup" -> CleanupScreen(
            scanner = scanner,
            onBack = { screen = "home" }
        )
        "website" -> InfoScreen(
            title = "Website Protection",
            description = "DNS/VPN filtering is not enabled in this build. No websites are currently being blocked by LOCKGUARD.",
            status = "Not configured",
            onBack = { screen = "home" }
        )
        "install" -> InstallProtectionScreen(
            context = context,
            onBack = { screen = "home" }
        )
        "activity" -> ActivityScreen(context = context, onBack = { screen = "home" })
        else -> DashboardScreen(
            context = context,
            protectionOn = protectionOn,
            pinConfigured = pinConfigured,
            onToggle = {
                if (protectionOn) {
                    requireAdmin { protectionOn = false }
                } else {
                    protectionOn = true
                }
            },
            onCleanup = { screen = "cleanup" },
            onWebsite = { screen = "website" },
            onInstall = { screen = "install" },
            onActivity = { screen = "activity" },
            onAdmin = {
                requireAdmin { screen = "activity" }
            },
            onSetupPin = { screen = "pin_setup" }
        )
    }
}

@Composable
private fun DashboardScreen(
    context: Context,
    protectionOn: Boolean,
    pinConfigured: Boolean,
    onToggle: () -> Unit,
    onCleanup: () -> Unit,
    onWebsite: () -> Unit,
    onInstall: () -> Unit,
    onActivity: () -> Unit,
    onAdmin: () -> Unit,
    onSetupPin: () -> Unit
) {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val admin = ComponentName(context, LockGuardDeviceAdminReceiver::class.java)
    val isDeviceOwner = dpm.isDeviceOwnerApp(context.packageName)

    Scaffold(containerColor = Bg) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(42.dp).background(Accent, RoundedCornerShape(13.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Shield, null, tint = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("LOCKGUARD", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                        Text("DEVICE PROTECTION", color = TextMuted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = onAdmin) { Icon(Icons.Default.Settings, "Administrator settings", tint = TextMuted) }
                }
            }
            item {
                Column(
                    Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(24.dp)).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("MASTER PROTECTION", color = TextMuted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.size(118.dp).background(if (protectionOn) Color(0xFF193A2A) else SurfaceLight, RoundedCornerShape(60.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PowerSettingsNew, null, tint = if (protectionOn) Green else Accent, modifier = Modifier.size(54.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(if (protectionOn) "REQUESTED ON" else "OFF", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (protectionOn) "Only supported modules can be active." else "Protection modules are not enforcing policies.",
                        color = TextMuted, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = onToggle,
                        colors = ButtonDefaults.buttonColors(containerColor = if (protectionOn) SurfaceLight else Accent),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(if (protectionOn) "TURN PROTECTION OFF" else "ENABLE PROTECTION", fontWeight = FontWeight.Bold)
                    }
                    if (!pinConfigured) {
                        TextButton(onClick = onSetupPin) { Text("Set administrator PIN", color = Amber) }
                    }
                }
            }
            item {
                Text("PROTECTION MODULES", color = TextMuted, fontSize = 11.sp, letterSpacing = 1.8.sp)
            }
            item {
                ModuleCard(Icons.Default.Apps, "APK Installation", "Personal mode: limited controls", "View details", onInstall)
            }
            item {
                ModuleCard(Icons.Default.Language, "Website Protection", "DNS filtering not configured", "View details", onWebsite)
            }
            item {
                ModuleCard(Icons.Default.DeleteSweep, "APK File Cleanup", "Scan and remove APK files you select", "Open scanner", onCleanup)
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InfoTile("DEVICE MODE", if (isDeviceOwner) "Device Owner" else "Personal", Modifier.weight(1f))
                    InfoTile("ADMIN PIN", if (pinConfigured) "Configured" else "Not set", Modifier.weight(1f))
                }
            }
            item {
                ModuleCard(Icons.Default.History, "Security Activity", "Local app activity and cleanup events", "View activity", onActivity)
            }
            item {
                Text(
                    "LOCKGUARD does not silently control Android. Actual enforcement depends on device mode, permissions and user consent.",
                    color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun ModuleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    action: String,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextMuted, fontSize = 11.sp)
        }
        Text(action, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoTile(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(SurfaceDark, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(title, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun CleanupScreen(scanner: ApkScanner, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var files by remember { mutableStateOf<List<ApkDocument>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var scanning by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Choose a folder to scan accessible APK files.") }
    var showConfirm by remember { mutableStateOf(false) }
    var totalDeleted by remember { mutableIntStateOf(0) }
    var recovered by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            scanning = true
            message = "Scanning selected folder…"
            scope.launch {
                files = scanner.scanTree(uri)
                selected = files.map { it.uri.toString() }.toSet()
                scanning = false
                message = if (files.isEmpty()) "No APK files found in the selected folder." else "Found ${files.size} APK file(s). Review before deleting."
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("Delete selected APK files?") },
            text = { Text("This deletes only the selected .apk files from the folder you granted access to. Installed apps and app data are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    deleting = true
                    scope.launch {
                        val targets = files.filter { it.uri.toString() in selected }
                        val result = scanner.deleteSelected(targets)
                        totalDeleted += result.deleted
                        recovered += result.bytesRecovered
                        files = files.filterNot { it.uri.toString() in result.deletedUris }
                        selected = emptySet()
                        deleting = false
                        message = "Deleted: ${result.deleted} • Failed: ${result.failed} • Recovered: ${formatBytes(result.bytesRecovered)}"
                    }
                }) { Text("DELETE", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("Cancel") } }
        )
    }

    Scaffold(containerColor = Bg, topBar = {
        TopAppBarSimple("APK CLEANUP", onBack)
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
            Text("Scan only folders you explicitly authorize.", color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatBox("FOUND", files.size.toString(), Modifier.weight(1f))
                StatBox("SELECTED", selected.size.toString(), Modifier.weight(1f))
                StatBox("SIZE", formatBytes(files.filter { it.uri.toString() in selected }.sumOf { it.sizeBytes }), Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { folderPicker.launch(null) },
                enabled = !scanning && !deleting,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("CHOOSE FOLDER TO SCAN") }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { selected = files.map { it.uri.toString() }.toSet() }) { Text("Select all") }
                TextButton(onClick = { selected = emptySet() }) { Text("Deselect all") }
            }
            if (scanning || deleting) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
            Text(message, color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(files, key = { it.uri.toString() }) { file ->
                    Row(
                        Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(12.dp))
                            .clickable {
                                val key = file.uri.toString()
                                selected = if (key in selected) selected - key else selected + key
                            }.padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = file.uri.toString() in selected,
                            onCheckedChange = { checked ->
                                val key = file.uri.toString()
                                selected = if (checked) selected + key else selected - key
                            },
                            colors = CheckboxDefaults.colors(checkedColor = Accent)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(file.name, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            Text(file.path, color = TextMuted, fontSize = 10.sp, maxLines = 1)
                            Text(formatBytes(file.sizeBytes), color = TextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
            Button(
                onClick = { showConfirm = true },
                enabled = selected.isNotEmpty() && !deleting && !scanning,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.DeleteForever, null)
                Spacer(Modifier.width(8.dp))
                Text("DELETE SELECTED APKs (${selected.size})", fontWeight = FontWeight.Bold)
            }
            Text("Session deleted: $totalDeleted • Space recovered: ${formatBytes(recovered)}", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

package com.lockguard.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.lockguard.app.admin.LockGuardDeviceAdminReceiver
import com.lockguard.app.security.PinVault
import com.lockguard.app.storage.ApkDocument
import com.lockguard.app.storage.ApkScanner
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private val Bg = Color(0xFF0B0D10)
private val SurfaceDark = Color(0xFF15191F)
private val SurfaceLight = Color(0xFF20262E)
private val Accent = Color(0xFFE34B55)
private val TextMain = Color(0xFFF4F5F7)
private val TextMuted = Color(0xFF9AA4B2)
private val Green = Color(0xFF55C98A)
private val Amber = Color(0xFFFFC15A)

class MainActivity : ComponentActivity() {
    private lateinit var vault: PinVault
    private lateinit var scanner: ApkScanner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vault = PinVault(this)
        scanner = ApkScanner(this)

        setContent {
            LockGuardTheme {
                LockGuardApp(
                    context = this,
                    vault = vault,
                    scanner = scanner
                )
            }
        }
    }
}

@Composable
private fun LockGuardTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = SurfaceDark,
            onBackground = TextMain,
            onSurface = TextMain
        ),
        content = content
    )
}

@Composable
private fun LockGuardApp(
    context: Context,
    vault: PinVault,
    scanner: ApkScanner
) {
    var screen by remember { mutableStateOf("home") }
    var protectionOn by remember { mutableStateOf(false) }
    var pinConfigured by remember { mutableStateOf(vault.hasPin()) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun requireAdmin(action: () -> Unit) {
        if (!pinConfigured) {
            pendingAction = action
            screen = "pin_setup"
        } else {
            pendingAction = action
            showPinDialog = true
        }
    }

    if (showPinDialog) {
        PinDialog(
            title = "Administrator authentication",
            confirmLabel = "Verify",
            onDismiss = { showPinDialog = false },
            onConfirm = { pin ->
                val ok = vault.verify(pin.toCharArray())
                showPinDialog = false
                if (ok) pendingAction?.invoke()
            }
        )
    }

    when (screen) {
        "pin_setup" -> PinSetupScreen(
            onBack = { screen = "home" },
            onSave = { pin ->
                vault.setPin(pin.toCharArray())
                pinConfigured = true
                val action = pendingAction
                pendingAction = null
                screen = "home"
                action?.invoke()
            }
        )
        "cleanup" -> CleanupScreen(
            scanner = scanner,
            onBack = { screen = "home" }
        )
        "website" -> InfoScreen(
            title = "Website Protection",
            description = "DNS/VPN filtering is not enabled in this build. No websites are currently being blocked by LOCKGUARD.",
            status = "Not configured",
            onBack = { screen = "home" }
        )
        "install" -> InstallProtectionScreen(
            context = context,
            onBack = { screen = "home" }
        )
        "activity" -> ActivityScreen(context = context, onBack = { screen = "home" })
        else -> DashboardScreen(
            context = context,
            protectionOn = protectionOn,
            pinConfigured = pinConfigured,
            onToggle = {
                if (protectionOn) {
                    requireAdmin { protectionOn = false }
                } else {
                    protectionOn = true
                }
            },
            onCleanup = { screen = "cleanup" },
            onWebsite = { screen = "website" },
            onInstall = { screen = "install" },
            onActivity = { screen = "activity" },
            onAdmin = {
                requireAdmin { screen = "activity" }
            },
            onSetupPin = { screen = "pin_setup" }
        )
    }
}

@Composable
private fun DashboardScreen(
    context: Context,
    protectionOn: Boolean,
    pinConfigured: Boolean,
    onToggle: () -> Unit,
    onCleanup: () -> Unit,
    onWebsite: () -> Unit,
    onInstall: () -> Unit,
    onActivity: () -> Unit,
    onAdmin: () -> Unit,
    onSetupPin: () -> Unit
) {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val admin = ComponentName(context, LockGuardDeviceAdminReceiver::class.java)
    val isDeviceOwner = dpm.isDeviceOwnerApp(context.packageName)

    Scaffold(containerColor = Bg) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(42.dp).background(Accent, RoundedCornerShape(13.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Shield, null, tint = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("LOCKGUARD", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                        Text("DEVICE PROTECTION", color = TextMuted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = onAdmin) { Icon(Icons.Default.Settings, "Administrator settings", tint = TextMuted) }
                }
            }
            item {
                Column(
                    Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(24.dp)).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("MASTER PROTECTION", color = TextMuted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.size(118.dp).background(if (protectionOn) Color(0xFF193A2A) else SurfaceLight, RoundedCornerShape(60.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PowerSettingsNew, null, tint = if (protectionOn) Green else Accent, modifier = Modifier.size(54.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(if (protectionOn) "REQUESTED ON" else "OFF", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (protectionOn) "Only supported modules can be active." else "Protection modules are not enforcing policies.",
                        color = TextMuted, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = onToggle,
                        colors = ButtonDefaults.buttonColors(containerColor = if (protectionOn) SurfaceLight else Accent),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(if (protectionOn) "TURN PROTECTION OFF" else "ENABLE PROTECTION", fontWeight = FontWeight.Bold)
                    }
                    if (!pinConfigured) {
                        TextButton(onClick = onSetupPin) { Text("Set administrator PIN", color = Amber) }
                    }
                }
            }
            item {
                Text("PROTECTION MODULES", color = TextMuted, fontSize = 11.sp, letterSpacing = 1.8.sp)
            }
            item {
                ModuleCard(Icons.Default.Apps, "APK Installation", "Personal mode: limited controls", "View details", onInstall)
            }
            item {
                ModuleCard(Icons.Default.Language, "Website Protection", "DNS filtering not configured", "View details", onWebsite)
            }
            item {
                ModuleCard(Icons.Default.DeleteSweep, "APK File Cleanup", "Scan and remove APK files you select", "Open scanner", onCleanup)
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InfoTile("DEVICE MODE", if (isDeviceOwner) "Device Owner" else "Personal", Modifier.weight(1f))
                    InfoTile("ADMIN PIN", if (pinConfigured) "Configured" else "Not set", Modifier.weight(1f))
                }
            }
            item {
                ModuleCard(Icons.Default.History, "Security Activity", "Local app activity and cleanup events", "View activity", onActivity)
            }
            item {
                Text(
                    "LOCKGUARD does not silently control Android. Actual enforcement depends on device mode, permissions and user consent.",
                    color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun ModuleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    action: String,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextMuted, fontSize = 11.sp)
        }
        Text(action, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoTile(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(SurfaceDark, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(title, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun CleanupScreen(scanner: ApkScanner, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var files by remember { mutableStateOf<List<ApkDocument>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var scanning by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Choose a folder to scan accessible APK files.") }
    var showConfirm by remember { mutableStateOf(false) }
    var totalDeleted by remember { mutableIntStateOf(0) }
    var recovered by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            scanning = true
            message = "Scanning selected folder…"
            scope.launch {
                files = scanner.scanTree(uri)
                selected = files.map { it.uri.toString() }.toSet()
                scanning = false
                message = if (files.isEmpty()) "No APK files found in the selected folder." else "Found ${files.size} APK file(s). Review before deleting."
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("Delete selected APK files?") },
            text = { Text("This deletes only the selected .apk files from the folder you granted access to. Installed apps and app data are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    deleting = true
                    scope.launch {
                        val targets = files.filter { it.uri.toString() in selected }
                        val result = scanner.deleteSelected(targets)
                        totalDeleted += result.deleted
                        recovered += result.bytesRecovered
                        files = files.filterNot { it.uri.toString() in result.deletedUris }
                        selected = emptySet()
                        deleting = false
                        message = "Deleted: ${result.deleted} • Failed: ${result.failed} • Recovered: ${formatBytes(result.bytesRecovered)}"
                    }
                }) { Text("DELETE", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("Cancel") } }
        )
    }

    Scaffold(containerColor = Bg, topBar = {
        TopAppBarSimple("APK CLEANUP", onBack)
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
            Text("Scan only folders you explicitly authorize.", color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatBox("FOUND", files.size.toString(), Modifier.weight(1f))
                StatBox("SELECTED", selected.size.toString(), Modifier.weight(1f))
                StatBox("SIZE", formatBytes(files.filter { it.uri.toString() in selected }.sumOf { it.sizeBytes }), Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { folderPicker.launch(null) },
                enabled = !scanning && !deleting,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("CHOOSE FOLDER TO SCAN") }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { selected = files.map { it.uri.toString() }.toSet() }) { Text("Select all") }
                TextButton(onClick = { selected = emptySet() }) { Text("Deselect all") }
            }
            if (scanning || deleting) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
            Text(message, color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(files, key = { it.uri.toString() }) { file ->
                    Row(
                        Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(12.dp))
                            .clickable {
                                val key = file.uri.toString()
                                selected = if (key in selected) selected - key else selected + key
                            }.padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = file.uri.toString() in selected,
                            onCheckedChange = { checked ->
                                val key = file.uri.toString()
                                selected = if (checked) selected + key else selected - key
                            },
                            colors = CheckboxDefaults.colors(checkedColor = Accent)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(file.name, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            Text(file.path, color = TextMuted, fontSize = 10.sp, maxLines = 1)
                            Text(formatBytes(file.sizeBytes), color = TextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
            Button(
                onClick = { showConfirm = true },
                enabled = selected.isNotEmpty() && !deleting && !scanning,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.DeleteForever, null)
                Spacer(Modifier.width(8.dp))
                Text("DELETE SELECTED APKs (${selected.size})", fontWeight = FontWeight.Bold)
            }
            Text("Session deleted: $totalDeleted • Space recovered: ${formatBytes(recovered)}", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

private suspend fun ApkScanner.scanTreeFromUrisFallback(
    old: List<ApkDocument>,
    selected: Set<String>,
    deletedCount: Int
): List<ApkDocument> {
    // Remove only confirmed deletions from the current visible list. Failed items remain visible.
    // A fresh folder scan is available by choosing the folder again.
    return if (deletedCount == 0) old else old.filterNot { it.uri.toString() in selected }
}

@Composable
private fun StatBox(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(SurfaceDark, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(title, color = TextMuted, fontSize = 9.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun InstallProtectionScreen(context: Context, onBack: () -> Unit) {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val isOwner = dpm.isDeviceOwnerApp(context.packageName)
    var status by remember { mutableStateOf("Not applied by this screen") }

    Scaffold(containerColor = Bg, topBar = { TopAppBarSimple("APK INSTALLATION", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            InfoTile("DEVICE MANAGEMENT MODE", if (isOwner) "Device Owner" else "Personal device")
            Text("What this build supports", color = TextMain, fontWeight = FontWeight.Bold)
            Text("On ordinary devices, LOCKGUARD cannot globally prevent every app installation or override Android's per-source permission controls.", color = TextMuted)
            Text("On a properly provisioned Device Owner device, Android supports selected user restrictions. This sample can apply the unknown-source restriction after administrator confirmation.", color = TextMuted)
            Button(
                onClick = {
                    if (isOwner) {
                        try {
                            dpm.addUserRestriction(
                                ComponentName(context, LockGuardDeviceAdminReceiver::class.java),
                                android.os.UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES
                            )
                            status = "Restriction request applied; verify device policy state in management tooling."
                        } catch (e: Exception) {
                            status = "Could not apply: ${e.message ?: "permission or policy error"}"
                        }
                    } else {
                        status = "Unavailable: this app is not Device Owner."
                    }
                },
                enabled = isOwner,
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Text("APPLY SUPPORTED RESTRICTION") }
            Text(status, color = Amber)
            Text("This is not a full application allowlist. Managed Google Play / EMM is the appropriate route for enterprise app distribution control.", color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun InfoScreen(title: String, description: String, status: String, onBack: () -> Unit) {
    Scaffold(containerColor = Bg, topBar = { TopAppBarSimple(title.uppercase(), onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            InfoTile("MODULE STATUS", status)
            Text(description, color = TextMuted)
            Text("LOCKGUARD will not report this module as active until a real filtering engine is configured and verified.", color = Amber)
        }
    }
}

@Composable
private fun PinSetupScreen(onBack: () -> Unit, onSave: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Scaffold(containerColor = Bg, topBar = { TopAppBarSimple("ADMINISTRATOR SETUP", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Create administrator PIN", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Use 6–12 digits. Your PIN is not stored as plaintext.", color = TextMuted)
            OutlinedTextField(
                value = pin, onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) pin = it },
                label = { Text("New PIN") }, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = confirm, onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) confirm = it },
                label = { Text("Confirm PIN") }, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            error?.let { Text(it, color = Accent) }
            Button(
                onClick = {
                    if (pin.length !in 6..12) error = "PIN must be 6–12 digits."
                    else if (pin != confirm) error = "PINs do not match."
                    else onSave(pin)
                },
                modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Text("SAVE ADMIN PIN") }
        }
    }
}

@Composable
private fun PinDialog(
    title: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = pin,
                onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) pin = it },
                label = { Text("Administrator PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(pin) }) { Text(confirmLabel, color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ActivityScreen(context: Context, onBack: () -> Unit) {
    Scaffold(containerColor = Bg, topBar = { TopAppBarSimple("SECURITY ACTIVITY", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Local activity", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("This starter version records cleanup results in the current session only. Persistent audit history is planned for the Room database stage.", color = TextMuted)
            Text("No browsing history is collected.", color = Green)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarSimple(title: String, onBack: () -> Unit) {
    TopAppBar(
        title = { Text(title, fontSize = 13.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = TextMain, navigationIconContentColor = TextMain)
    )
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb / 1024.0)
}
